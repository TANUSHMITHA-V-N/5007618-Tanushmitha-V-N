package com.example.Bookstoreapi.resource;

import com.example.Bookstoreapi.controller.CustomerController;
import com.example.Bookstoreapi.dto.CustomerDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Component;

@Component
public class CustomerResource extends EntityModel<CustomerDTO> {
    public CustomerResource(CustomerDTO content) {
        super(content);
        add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getCustomerById(content.getId())).withSelfRel());
        add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(CustomerController.class).getAllCustomers()).withRel("customers"));
    }
}
