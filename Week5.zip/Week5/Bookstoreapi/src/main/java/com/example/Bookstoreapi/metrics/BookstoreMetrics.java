package com.example.Bookstoreapi.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;

@Component
public class BookstoreMetrics {
    private final Counter bookCreatedCounter;
    private final Counter bookUpdatedCounter;
    private final Counter bookDeletedCounter;

    public BookstoreMetrics(MeterRegistry meterRegistry) {
        bookCreatedCounter = Counter.builder("book.created")
                .description("Number of books created")
                .register(meterRegistry);
        bookUpdatedCounter = Counter.builder("book.updated")
                .description("Number of books updated")
                .register(meterRegistry);
        bookDeletedCounter = Counter.builder("book.deleted")
                .description("Number of books deleted")
                .register(meterRegistry);
    }

    public void incrementBookCreatedCounter() {
        bookCreatedCounter.increment();
    }

    public void incrementBookUpdatedCounter() {
        bookUpdatedCounter.increment();
    }

    public void incrementBookDeletedCounter() {
        bookDeletedCounter.increment();
    }
}
