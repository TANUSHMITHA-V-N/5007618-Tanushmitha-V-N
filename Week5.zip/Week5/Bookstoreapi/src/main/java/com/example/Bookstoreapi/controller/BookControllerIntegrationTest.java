package com.example.Bookstoreapi.controller;

import com.example.Bookstoreapi.BookstoreApiApplication;
import com.example.Bookstoreapi.model.Book;
import com.example.Bookstoreapi.repository.BookRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = BookstoreApiApplication.class)
@AutoConfigureMockMvc
public class BookControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BookRepository bookRepository;

    @Before
    public void setup() {
        bookRepository.deleteAll();
    }

    @Test
    public void testGetBooks() throws Exception {
        mockMvc.perform(get("/api/books"))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetBookById() throws Exception {
        Book book = new Book("Book 1", "Author 1");
        bookRepository.save(book);

        mockMvc.perform(get("/api/books/" + book.getId()))
                .andExpect(status().isOk());
    }

    @Test
    public void testCreateBook() throws Exception {
        String requestBody = "{\"title\":\"Book 2\",\"author\":\"Author 2\"}";

        mockMvc.perform(post("/api/books")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(requestBody))
                .andExpect(status().isCreated());
    }

    @Test
    public void testUpdateBook() throws Exception {
        Book book = new Book("Book 1", "Author 1");
        bookRepository.save(book);

        String requestBody = "{\"title\":\"Book 1 Updated\",\"author\":\"Author 1 Updated\"}";

        mockMvc.perform(put("/api/books/" + book.getId())
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .content(requestBody))
                .andExpect(status().isOk());
    }

    @Test
    public void testDeleteBook() throws Exception {
        Book book = new Book("Book 1", "Author 1");
        bookRepository.save(book);

        mockMvc.perform(delete("/api/books/" + book.getId()))
                .andExpect(status().isNoContent());
    }
}
