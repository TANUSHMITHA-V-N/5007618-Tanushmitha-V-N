package com.example.Bookstoreapi.mapper;

import com.example.Bookstoreapi.dto.CustomerDTO;
import com.example.Bookstoreapi.model.Customer;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CustomerMapper {
    @Mapping(target = "id", source = "id")
    CustomerDTO customerToCustomerDTO(Customer customer);

    @Mapping(target = "id", source = "id")
    Customer customerDTOToCustomer(CustomerDTO customerDTO);
}
