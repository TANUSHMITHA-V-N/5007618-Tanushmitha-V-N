package com.example.Bookstoreapi.mapper;

import com.example.Bookstoreapi.dto.BookDTO;
import com.example.Bookstoreapi.model.Book;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface BookMapper {
    @Mapping(target = "id", source = "id")
    BookDTO bookToBookDTO(Book book);

    @Mapping(target = "id", source = "id")
    Book bookDTOToBook(BookDTO bookDTO);
}
