package com.example.Bookstoreapi.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Bookstoreapi.exception.BookNotFoundException;
import com.example.Bookstoreapi.exception.InvalidBookDataException;
import com.example.Bookstoreapi.model.Book;

@RestController
@RequestMapping("/books")
public class BookController {
    private List<Book> books = new ArrayList<>();

    @GetMapping
    public ResponseEntity<List<Book>> getBooksByTitleAndAuthor(
            @RequestParam(required = false) String title,
            @RequestParam(required = false) String author) {
        List<Book> filteredBooks = books.stream()
                .filter(b -> (title == null || b.getTitle().contains(title))
                        && (author == null || b.getAuthor().contains(author)))
                .collect(Collectors.toList());
        
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Books retrieved successfully");
        return new ResponseEntity<>(filteredBooks, headers, HttpStatus.OK);
    }

    @GetMapping("/{id}")
public ResponseEntity<Book> getBookById(@PathVariable Long id) {
    Book book = books.stream()
            .filter(b -> b.getId().equals(id))
            .findFirst()
            .orElseThrow(() -> new BookNotFoundException("Book not found"));
    return ResponseEntity.ok(book);
}

@PostMapping
public ResponseEntity<Book> createBook(@RequestBody Book book) {
    if (book.getTitle() == null || book.getAuthor() == null) {
        throw new InvalidBookDataException("Invalid book data");
    }
    books.add(book);
    return ResponseEntity.status(HttpStatus.CREATED).body(book);
}

    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book book) {
        Book existingBook = books.stream()
                .filter(b -> b.getId().equals(id))
                .findFirst()
                .orElse(null);
        
        if (existingBook != null) {
            existingBook.setTitle(book.getTitle());
            existingBook.setAuthor(book.getAuthor());
            existingBook.setPrice(book.getPrice());
            existingBook.setIsbn(book.getIsbn());
            
            HttpHeaders headers = new HttpHeaders();
            headers.add("X-Custom-Header", "Book updated successfully");
            return new ResponseEntity<>(existingBook, headers, HttpStatus.OK);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long id) {
        books.removeIf(b -> b.getId().equals(id));
        
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Custom-Header", "Book deleted successfully");
        return new ResponseEntity<>(headers, HttpStatus.NO_CONTENT);
    }
}