public class EmployeeManagementSystem {
    private Employee[] employees;
    private int employeeCount;

    public EmployeeManagementSystem(int maxEmployees) {
        employees = new Employee[maxEmployees];
        employeeCount = 0;
    }

    // Add an employee to the array
    public void addEmployee(Employee employee) {
        if (employeeCount < employees.length) {
            employees[employeeCount] = employee;
            employeeCount++;
            System.out.println("Employee added successfully!");
        } else {
            System.out.println("Employee array is full. Cannot add more employees.");
        }
    }

    // Search for an employee by ID
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < employeeCount; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }

    // Traverse the employee array and print all employees
    public void traverseEmployees() {
        for (int i = 0; i < employeeCount; i++) {
            System.out.println("Employee ID: " + employees[i].getEmployeeId() + ", Name: " + employees[i].getName() + ", Position: " + employees[i].getPosition() + ", Salary: " + employees[i].getSalary());
        }
    }

    // Delete an employee by ID
    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < employeeCount; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                // Shift all employees after the deleted employee to the left
                for (int j = i; j < employeeCount - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employeeCount--;
                System.out.println("Employee deleted successfully!");
                return;
            }
        }
        System.out.println("Employee not found. Cannot delete.");
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);

        Employee employee1 = new Employee(1, "John Doe", "Software Engineer", 50000.0);
        Employee employee2 = new Employee(2, "Jane Doe", "Data Scientist", 60000.0);
        Employee employee3 = new Employee(3, "Bob Smith", "Product Manager", 70000.0);

        ems.addEmployee(employee1);
        ems.addEmployee(employee2);
        ems.addEmployee(employee3);

        System.out.println("All Employees:");
        ems.traverseEmployees();

        Employee searchedEmployee = ems.searchEmployee(2);
        if (searchedEmployee != null) {
            System.out.println("Searched Employee:");
            System.out.println("Employee ID: " + searchedEmployee.getEmployeeId() + ", Name: " + searchedEmployee.getName() + ", Position: " + searchedEmployee.getPosition() + ", Salary: " + searchedEmployee.getSalary());
        } else {
            System.out.println("Employee not found.");
        }

        ems.deleteEmployee(2);

        System.out.println("All Employees after deletion:");
        ems.traverseEmployees();
    }
}
