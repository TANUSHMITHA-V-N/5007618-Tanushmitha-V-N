
public class FinancialForecaster {
  
    public static double calculateFutureValue(double presentValue, double growthRate, int periods) {
        if (periods == 0) {
            return presentValue;
        }
        else {
            double futureValue = presentValue * (1 + growthRate);
            return calculateFutureValue(futureValue, growthRate, periods - 1);
        }
    }

    public static void main(String[] args) {
        double presentValue = 1000; // initial investment
        double growthRate = 0.05; // 5% growth rate per period
        int periods = 5; // forecast for 5 periods

        double futureValue = calculateFutureValue(presentValue, growthRate, periods);
        System.out.println("Future Value: " + futureValue);
    }
}