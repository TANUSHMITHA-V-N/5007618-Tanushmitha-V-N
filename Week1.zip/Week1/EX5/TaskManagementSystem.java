public class TaskManagementSystem {
    private Node head;

    private class Node {
        Task task;
        Node next;

        public Node(Task task) {
            this.task = task;
            this.next = null;
        }
    }

    // Add a task to the linked list
    public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next!= null) {
                current = current.next;
            }
            current.next = newNode;
        }
        System.out.println("Task added successfully!");
    }


    public Task searchTask(int taskId) {
        Node current = head;
        while (current!= null) {
            if (current.task.getTaskId() == taskId) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }

 
    public void traverseTasks() {
        Node current = head;
        while (current!= null) {
            System.out.println("Task ID: " + current.task.getTaskId() + ", Task Name: " + current.task.getTaskName() + ", Status: " + current.task.getStatus());
            current = current.next;
        }
    }

    
    public void deleteTask(int taskId) {
        if (head == null) {
            System.out.println("Task list is empty. Cannot delete.");
            return;
        }

        if (head.task.getTaskId() == taskId) {
            head = head.next;
            System.out.println("Task deleted successfully!");
            return;
        }

        Node current = head;
        while (current.next!= null) {
            if (current.next.task.getTaskId() == taskId) {
                current.next = current.next.next;
                System.out.println("Task deleted successfully!");
                return;
            }
            current = current.next;
        }
        System.out.println("Task not found. Cannot delete.");
    }

    public static void main(String[] args) {
        TaskManagementSystem tms = new TaskManagementSystem();

        Task task1 = new Task(1, "Task 1", "In Progress");
        Task task2 = new Task(2, "Task 2", "Completed");
        Task task3 = new Task(3, "Task 3", "Pending");

        tms.addTask(task1);
        tms.addTask(task2);
        tms.addTask(task3);

        System.out.println("All Tasks:");
        tms.traverseTasks();

        Task searchedTask = tms.searchTask(2);
        if (searchedTask!= null) {
            System.out.println("Searched Task:");
            System.out.println("Task ID: " + searchedTask.getTaskId() + ", Task Name: " + searchedTask.getTaskName() + ", Status: " + searchedTask.getStatus());
        } else {
            System.out.println("Task not found.");
        }

        tms.deleteTask(2);

        System.out.println("All Tasks after deletion:");
        tms.traverseTasks();
    }
}
