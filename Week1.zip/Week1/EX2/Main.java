public class Main {
    
    // Linear Search
    public static int linearSearch(Product[] products, int targetId) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductId() == targetId) {
                return i; // Return the index of the found product
            }
        }
        return -1; // Return -1 if the product is not found
    }

    // Binary Search
    public static int binarySearch(Product[] sortedProducts, int targetId) {
        int left = 0;
        int right = sortedProducts.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (sortedProducts[mid].getProductId() == targetId) {
                return mid; // Return the index of the found product
            } else if (sortedProducts[mid].getProductId() < targetId) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // Return -1 if the product is not found
    }

    public static void main(String[] args) {
        // Create an array of products for linear search
        Product[] products = new Product[] {
            new Product(1, "Product A", "Category X"),
            new Product(2, "Product B", "Category Y"),
            new Product(3, "Product C", "Category Z"),
            new Product(4, "Product D", "Category X"),
            new Product(5, "Product E", "Category Y")
        };

        // Create a sorted array of products for binary search
        Product[] sortedProducts = new Product[] {
            new Product(1, "Product A", "Category X"),
            new Product(2, "Product B", "Category Y"),
            new Product(3, "Product C", "Category Z"),
            new Product(4, "Product D", "Category X"),
            new Product(5, "Product E", "Category Y")
        };

        int targetId = 3;

        // Perform linear search
        int linearSearchResult = linearSearch(products, targetId);
        System.out.println("Linear Search Result: " + linearSearchResult);

        // Perform binary search
        int binarySearchResult = binarySearch(sortedProducts, targetId);
        System.out.println("Binary Search Result: " + binarySearchResult);
    }
}
