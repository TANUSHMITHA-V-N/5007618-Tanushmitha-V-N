// Main.java

public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        // Add some products
        Product product1 = new Product(1, "Product A", 10, 9.99);
        Product product2 = new Product(2, "Product B", 20, 19.99);
        Product product3 = new Product(3, "Product C", 30, 29.99);

        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);

        // Print all products
        System.out.println("All Products:");
        inventory.printProducts();

        // Update a product
        Product updatedProduct = new Product(2, "Product B Updated", 25, 24.99);
        inventory.updateProduct(updatedProduct);

        // Print all products again
        System.out.println("All Products after update:");
        inventory.printProducts();

        // Delete a product
        inventory.deleteProduct(3);

        // Print all products again
        System.out.println("All Products after delete:");
        inventory.printProducts();
    }
}