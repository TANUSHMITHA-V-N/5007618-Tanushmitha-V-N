// Inventory.java

import java.util.HashMap;
import java.util.Map;

/**
 * Represents the inventory management system.
 */
public class Inventory {
    private Map<Integer, Product> products;

    public Inventory() {
        this.products = new HashMap<>();
    }

    /**
     * Adds a product to the inventory.
     *
     * @param product the product to add
     */
    public void addProduct(Product product) {
        products.put(product.getProductId(), product);
    }

    /**
     * Updates a product in the inventory.
     *
     * @param product the product to update
     */
    public void updateProduct(Product product) {
        if (products.containsKey(product.getProductId())) {
            products.put(product.getProductId(), product);
        }
    }

    /**
     * Deletes a product from the inventory.
     *
     * @param productId the ID of the product to delete
     */
    public void deleteProduct(int productId) {
        products.remove(productId);
    }

    /**
     * Retrieves a product from the inventory.
     *
     * @param productId the ID of the product to retrieve
     * @return the product, or null if not found
     */
    public Product getProduct(int productId) {
        return products.get(productId);
    }

    /**
     * Prints all products in the inventory.
     */
    public void printProducts() {
        for (Product product : products.values()) {
            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Product Name: " + product.getProductName());
            System.out.println("Quantity: " + product.getQuantity());
            System.out.println("Price: " + product.getPrice());
            System.out.println();
        }
    }
}