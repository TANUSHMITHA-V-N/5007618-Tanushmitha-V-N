import java.util.Arrays;

public class LibraryManagementSystem {
    private Book[] books;

    public LibraryManagementSystem(Book[] books) {
        this.books = books;
    }

    // Linear Search
    public Book linearSearchByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equals(title)) {
                return book;
            }
        }
        return null;
    }

    // Binary Search
    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, (b1, b2) -> b1.getTitle().compareTo(b2.getTitle()));
        int low = 0;
        int high = books.length - 1;

        while (low <= high) {
            int mid = (low + high) / 2;
            if (books[mid].getTitle().equals(title)) {
                return books[mid];
            } else if (books[mid].getTitle().compareTo(title) < 0) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Book book1 = new Book(1, "Book 1", "Author 1");
        Book book2 = new Book(2, "Book 2", "Author 2");
        Book book3 = new Book(3, "Book 3", "Author 3");
        Book book4 = new Book(4, "Book 4", "Author 4");
        Book book5 = new Book(5, "Book 5", "Author 5");

        Book[] books = {book1, book2, book3, book4, book5};

        LibraryManagementSystem lms = new LibraryManagementSystem(books);

        Book searchedBook = lms.linearSearchByTitle("Book 3");
        if (searchedBook != null) {
            System.out.println("Linear Search Result:");
            System.out.println("Book ID: " + searchedBook.getBookId() + ", Title: " + searchedBook.getTitle() + ", Author: " + searchedBook.getAuthor());
        } else {
            System.out.println("Book not found using linear search.");
        }

        searchedBook = lms.binarySearchByTitle("Book 3");
        if (searchedBook != null) {
            System.out.println("Binary Search Result:");
            System.out.println("Book ID: " + searchedBook.getBookId() + ", Title: " + searchedBook.getTitle() + ", Author: " + searchedBook.getAuthor());
        } else {
            System.out.println("Book not found using binary search.");
        }
    }
}