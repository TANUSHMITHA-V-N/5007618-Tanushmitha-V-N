package com.library.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class LoggingAspect {
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspect.class);

    @Before("execution(* com.library.*.*(..))")
    public void logBeforeMethodExecution(JoinPoint joinPoint) {
        LOGGER.info("Before executing method: {}", joinPoint.getSignature());
    }

    @After("execution(* com.library.*.*(..))")
    public void logAfterMethodExecution(JoinPoint joinPoint) {
        LOGGER.info("After executing method: {}", joinPoint.getSignature());
    }
}