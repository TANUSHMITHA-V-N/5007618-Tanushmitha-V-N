public class BookServiceImpl implements BookService {
    private BookRepository bookRepository;

    public BookServiceImpl(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void setAnotherRepository(BookRepository anotherRepository) {
        // Setter method for another repository
    }

    // Other methods...
}