// Book entity
@Entity
public class Book {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String author;
    // Getters and setters
}

// BookRepository interface
public interface BookRepository extends JpaRepository<Book, Long> {
}