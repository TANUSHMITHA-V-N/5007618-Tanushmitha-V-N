import org.springframework.stereotype.Service;

@Service
public class BookServiceImpl implements BookService {
    
}