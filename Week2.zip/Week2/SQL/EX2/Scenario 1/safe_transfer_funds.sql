CREATE OR REPLACE PROCEDURE SafeTransferFunds(
  p_from_account_id IN NUMBER,
  p_to_account_id IN NUMBER,
  p_amount IN NUMBER
) AS
BEGIN
  BEGIN
    -- Check if from_account has sufficient funds
    IF (SELECT balance FROM accounts WHERE account_id = p_from_account_id) < p_amount THEN
      RAISE_APPLICATION_ERROR(-20001, 'Insufficient funds in account ' || p_from_account_id);
    END IF;

    -- Perform the transfer
    UPDATE accounts
    SET balance = balance - p_amount
    WHERE account_id = p_from_account_id;

    UPDATE accounts
    SET balance = balance + p_amount
    WHERE account_id = p_to_account_id;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      INSERT INTO error_log (error_message, error_date)
      VALUES (SQLERRM, SYSTIMESTAMP);
      RAISE;
  END;
END SafeTransferFunds;