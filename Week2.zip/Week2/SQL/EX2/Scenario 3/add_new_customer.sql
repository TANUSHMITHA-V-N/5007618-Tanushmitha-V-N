CREATE OR REPLACE PROCEDURE AddNewCustomer(
  p_customer_id IN NUMBER,
  p_name IN VARCHAR2,
  p_address IN VARCHAR2
) AS
BEGIN
  BEGIN
    -- Check if customer already exists
    IF EXISTS (SELECT 1 FROM customers WHERE customer_id = p_customer_id) THEN
      RAISE_APPLICATION_ERROR(-20003, 'Customer ' || p_customer_id || ' already exists');
    END IF;

    -- Insert the new customer
    INSERT INTO customers (customer_id, name, address)
    VALUES (p_customer_id, p_name, p_address);

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      INSERT INTO error_log (error_message, error_date)
      VALUES (SQLERRM, SYSTIMESTAMP);
      RAISE;
  END;
END AddNewCustomer;