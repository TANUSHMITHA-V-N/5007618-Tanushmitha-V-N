CREATE OR REPLACE PROCEDURE UpdateSalary(
  p_employee_id IN NUMBER,
  p_percentage_increase IN NUMBER
) AS
BEGIN
  BEGIN
    -- Check if employee exists
    IF NOT EXISTS (SELECT 1 FROM employees WHERE employee_id = p_employee_id) THEN
      RAISE_APPLICATION_ERROR(-20002, 'Employee ' || p_employee_id || ' does not exist');
    END IF;

    -- Update the salary
    UPDATE employees
    SET salary = salary * (1 + p_percentage_increase / 100)
    WHERE employee_id = p_employee_id;

    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      INSERT INTO error_log (error_message, error_date)
      VALUES (SQLERRM, SYSTIMESTAMP);
      RAISE;
  END;
END UpdateSalary;