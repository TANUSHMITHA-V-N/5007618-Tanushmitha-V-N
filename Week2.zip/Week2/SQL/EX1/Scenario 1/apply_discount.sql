DECLARE
  CURSOR customers IS
    SELECT customer_id, age, loan_interest_rate
    FROM customers;

  customer customers%ROWTYPE;
BEGIN
  OPEN customers;
  LOOP
    FETCH customers INTO customer;
    EXIT WHEN customers%NOTFOUND;

    IF customer.age > 60 THEN
      UPDATE customers
      SET loan_interest_rate = loan_interest_rate - 0.01
      WHERE customer_id = customer.customer_id;
    END IF;
  END LOOP;
  CLOSE customers;
END;