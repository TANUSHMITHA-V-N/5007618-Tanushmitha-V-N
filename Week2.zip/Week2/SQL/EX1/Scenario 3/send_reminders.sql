DECLARE
  CURSOR loans IS
    SELECT loan_id, customer_id, due_date
    FROM loans
    WHERE due_date <= SYSTIMESTAMP + INTERVAL '30' DAY;

  loan loans%ROWTYPE;
BEGIN
  OPEN loans;
  LOOP
    FETCH loans INTO loan;
    EXIT WHEN loans%NOTFOUND;

    DBMS_OUTPUT.PUT_LINE('Reminder: Loan ' || loan.loan_id || ' for customer ' || loan.customer_id || ' is due on ' || loan.due_date);
  END LOOP;
  CLOSE loans;
END;