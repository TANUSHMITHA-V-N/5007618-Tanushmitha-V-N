DECLARE
  CURSOR customers IS
    SELECT customer_id, balance
    FROM customers;

  customer customers%ROWTYPE;
BEGIN
  OPEN customers;
  LOOP
    FETCH customers INTO customer;
    EXIT WHEN customers%NOTFOUND;

    IF customer.balance > 10000 THEN
      UPDATE customers
      SET is_vip = TRUE
      WHERE customer_id = customer.customer_id;
    END IF;
  END LOOP;
  CLOSE customers;
END;