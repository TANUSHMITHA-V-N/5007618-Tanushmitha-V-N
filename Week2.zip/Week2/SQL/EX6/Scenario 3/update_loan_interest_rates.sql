DECLARE
  new_interest_rate CONSTANT NUMBER := 0.05;  -- assume new interest rate is 5%
  CURSOR cur_loans IS
    SELECT LoanID, InterestRate
    FROM Loans;

  rec_loans cur_loans%ROWTYPE;
BEGIN
  OPEN cur_loans;
  LOOP
    FETCH cur_loans INTO rec_loans;
    EXIT WHEN cur_loans%NOTFOUND;

    UPDATE Loans
    SET InterestRate = new_interest_rate
    WHERE LoanID = rec_loans.LoanID;

    DBMS_OUTPUT.PUT_LINE('Interest rate updated to ' || new_interest_rate || ' for loan ' || rec_loans.LoanID);
  END LOOP;
  CLOSE cur_loans;
END;