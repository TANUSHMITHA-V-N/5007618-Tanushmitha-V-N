DECLARE
  annual_fee CONSTANT NUMBER := 25.00;  -- assume annual fee is $25.00
  CURSOR cur_accounts IS
    SELECT AccountID, Balance
    FROM Accounts;

  rec_accounts cur_accounts%ROWTYPE;
BEGIN
  OPEN cur_accounts;
  LOOP
    FETCH cur_accounts INTO rec_accounts;
    EXIT WHEN cur_accounts%NOTFOUND;

    UPDATE Accounts
    SET Balance = rec_accounts.Balance - annual_fee
    WHERE AccountID = rec_accounts.AccountID;

    DBMS_OUTPUT.PUT_LINE('Annual fee of $' || annual_fee || ' applied to account ' || rec_accounts.AccountID);
  END LOOP;
  CLOSE cur_accounts;
END;