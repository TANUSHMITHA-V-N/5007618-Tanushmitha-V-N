
DECLARE
  CURSOR cur_transactions IS
    SELECT c.CustomerID, c.CustomerName, t.TransactionDate, t.Amount, t.TransactionType
    FROM Customers c
    JOIN Transactions t ON c.CustomerID = t.CustomerID
    WHERE TRUNC(t.TransactionDate, 'MM') = TRUNC(SYSTIMESTAMP, 'MM');

  rec_transactions cur_transactions%ROWTYPE;
BEGIN
  OPEN cur_transactions;
  LOOP
    FETCH cur_transactions INTO rec_transactions;
    EXIT WHEN cur_transactions%NOTFOUND;

    DBMS_OUTPUT.PUT_LINE('Statement for ' || rec_transactions.CustomerName);
    DBMS_OUTPUT.PUT_LINE('Transaction Date: ' || rec_transactions.TransactionDate);
    DBMS_OUTPUT.PUT_LINE('Amount: ' || rec_transactions.Amount);
    DBMS_OUTPUT.PUT_LINE('Transaction Type: ' || rec_transactions.TransactionType);
    DBMS_OUTPUT.PUT_LINE('------------------------');
  END LOOP;
  CLOSE cur_transactions;
END;