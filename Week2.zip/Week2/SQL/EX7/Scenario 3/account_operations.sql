
CREATE OR REPLACE PACKAGE AccountOperations AS
  PROCEDURE OpenAccount(p_account_id IN Accounts.AccountID%TYPE, p_customer_id IN Accounts.CustomerID%TYPE, p_account_type IN Accounts.AccountType%TYPE);
  PROCEDURE CloseAccount(p_account_id IN Accounts.AccountID%TYPE);
  FUNCTION GetTotalBalance(p_customer_id IN Accounts.CustomerID%TYPE) RETURN NUMBER;
END AccountOperations;

CREATE OR REPLACE PACKAGE BODY AccountOperations AS
  PROCEDURE OpenAccount(p_account_id IN Accounts.AccountID%TYPE, p_customer_id IN Accounts.CustomerID%TYPE, p_account_type IN Accounts.AccountType%TYPE) AS
  BEGIN
    INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
    VALUES (p_account_id, p_customer_id, p_account_type, 0, SYSTIMESTAMP);
  END OpenAccount;

  PROCEDURE CloseAccount(p_account_id IN Accounts.AccountID%TYPE)