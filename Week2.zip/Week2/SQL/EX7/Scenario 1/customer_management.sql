
CREATE OR REPLACE PACKAGE CustomerManagement AS
  PROCEDURE AddCustomer(p_customer_id IN Customers.CustomerID%TYPE, p_name IN Customers.Name%TYPE, p_dob IN Customers.DOB%TYPE);
  PROCEDURE UpdateCustomerDetails(p_customer_id IN Customers.CustomerID%TYPE, p_name IN Customers.Name%TYPE, p_dob IN Customers.DOB%TYPE);
  FUNCTION GetCustomerBalance(p_customer_id IN Customers.CustomerID%TYPE) RETURN NUMBER;
END CustomerManagement;

CREATE OR REPLACE PACKAGE BODY CustomerManagement AS
  PROCEDURE AddCustomer(p_customer_id IN Customers.CustomerID%TYPE, p_name IN Customers.Name%TYPE, p_dob IN Customers.DOB%TYPE) AS
  BEGIN
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (p_customer_id, p_name, p_dob, 0, SYSTIMESTAMP);
  END AddCustomer;

  PROCEDURE UpdateCustomerDetails(p_customer_id IN Customers.CustomerID%TYPE, p_name IN Customers.Name%TYPE, p_dob IN Customers.DOB%TYPE) AS
  BEGIN
    UPDATE Customers
    SET Name = p_name, DOB = p_dob, LastModified = SYSTIMESTAMP
    WHERE CustomerID = p_customer_id;
  END UpdateCustomerDetails;

  FUNCTION GetCustomerBalance(p_customer_id IN Customers.CustomerID%TYPE) RETURN NUMBER AS
    v_balance NUMBER;
  BEGIN
    SELECT SUM(Balance) INTO v_balance
    FROM Accounts
    WHERE CustomerID = p_customer_id;
    RETURN v_balance;
  END GetCustomerBalance;
END CustomerManagement;