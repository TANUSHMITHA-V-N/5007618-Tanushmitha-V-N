package com.example.EmployeeManagementSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.repository.EmployeeRepository;
import com.example.EmployeeManagementSystem.service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    private final EmployeeRepository employeeRepository;
     private final EmployeeService employeeService;
    
    @Autowired
    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // 1. Pagination
    @GetMapping("/employees")
    public Page<Employee> getEmployees(@RequestParam int page, @RequestParam int size) {
        return employeeService.getEmployees(page, size);
    }

    // 2. Sorting
    @GetMapping("/employees/sortedByName")
    public List<Employee> getEmployeesSortedByName() {
        return employeeService.getEmployeesSortedByName();
    }

    @GetMapping("/employees/sortedBySalary")
    public List<Employee> getEmployeesSortedBySalary() {
        return employeeService.getEmployeesSortedBySalary();
    }

    // 3. Combining pagination and sorting
    @GetMapping("/employees/byDepartmentName")
    public Page<Employee> getEmployeesByDepartmentName(@RequestParam String departmentName, @RequestParam int page, @RequestParam int size) {
        return employeeService.getEmployeesByDepartmentName(departmentName, page, size);
    }

    @GetMapping("/employees/byNameStartingWith")
    public Page<Employee> getEmployeesByNameStartingWith(@RequestParam String name, @RequestParam int page, @RequestParam int size) {
        return employeeService.getEmployeesByNameStartingWith(name, page, size);
    }
    
    @Autowired
    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // Create Employee
    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        Employee newEmployee = employeeRepository.save(employee);
        return new ResponseEntity<>(newEmployee, HttpStatus.CREATED);
    }

    // Read All Employees
    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        List<Employee> employees = employeeRepository.findAll();
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    // Read Employee by ID
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        Employee employee = employeeRepository.findById(id).orElseThrow();
        return new ResponseEntity<>(employee, HttpStatus.OK);
    }

    // Update Employee
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        Employee existingEmployee = employeeRepository.findById(id).orElseThrow();
        existingEmployee.setName(employee.getName());
        existingEmployee.setDepartment(employee.getDepartment());
        Employee updatedEmployee = employeeRepository.save(existingEmployee);
        return new ResponseEntity<>(updatedEmployee, HttpStatus.OK);
    }

    // Delete Employee
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        employeeRepository.deleteById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
