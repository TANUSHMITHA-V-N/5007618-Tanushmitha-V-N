package com.example.EmployeeManagementSystem.repository;

import com.example.EmployeeManagementSystem.entity.employee.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface BatchEmployeeRepository extends JpaRepository<Employee, Long> {
@Modifying
    @Query("UPDATE Employee e SET e.name = :name WHERE e.id IN (:ids)")
    @Transactional
    int updateEmployeeNames(@Param("ids") List<Long> ids, @Param("name") String name);

}
