package com.example.EmployeeManagementSystem.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.Value;
import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.employeemanagementsystem.projections.EmployeeSummary;
import com.example.employeemanagementsystem.projections.DepartmentSummary;
import com.example.employeemanagementsystem.entity.employee.Employee


@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
   // 1. Pagination
    Page<Employee> findAll(Pageable pageable);

   // 2. Sorting
    @Query("SELECT e FROM Employee e ORDER BY e.name ASC")
    List<Employee> findEmployeesSortedByName();

    @Query("SELECT e FROM Employee e ORDER BY e.salary DESC")
    List<Employee> findEmployeesSortedBySalary();

   // 3. Combining pagination and sorting
    @Query("SELECT e FROM Employee e WHERE e.department.departmentName = ?1")
    Page<Employee> findEmployeesByDepartmentName(String departmentName, Pageable pageable);

    @Query("SELECT e FROM Employee e WHERE e.name LIKE ?1%")
    Page<Employee> findEmployeesByNameStartingWith(String name, Pageable pageable);

    @Value("#{target.id} #{target.name} #{target.department.name}")
    List<EmployeeSummary> findEmployeeSummaries();

    @EntityGraph(attributePaths = "department")
    @Value("#{target.department.id} #{target.department.name}")
    List<DepartmentSummary> findDepartmentSummaries();
}
