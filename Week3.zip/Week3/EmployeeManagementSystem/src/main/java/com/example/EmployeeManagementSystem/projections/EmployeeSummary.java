package com.example.EmployeeManagementSystem.projections;

import com.example.EmployeeManagementSystem.entity.Department;

public class EmployeeSummary {
    Long getId();
    String getName();
    Department getDepartment();

}
