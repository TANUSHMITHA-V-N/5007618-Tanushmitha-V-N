package com.example.EmployeeManagementSystem.service;

import com.example.EmployeeManagementSystem.entity.Employee;
import com.example.EmployeeManagementSystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    private final EmployeeRepository employeeRepository;

    @Autowired
    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // 1. Pagination
    public Page<Employee> getEmployees(int page, int size) {
        PageRequest pageRequest = PageRequest.of(page, size);
        return employeeRepository.findAll(pageRequest);
    }

    // 2. Sorting
    public List<Employee> getEmployeesSortedByName() {
        return employeeRepository.findEmployeesSortedByName();
    }

    public List<Employee> getEmployeesSortedBySalary() {
        return employeeRepository.findEmployeesSortedBySalary();
    }

    // 3. Combining pagination and sorting
    public Page<Employee> getEmployeesByDepartmentName(String departmentName, int page, int size) {
        PageRequest pageRequest = PageRequest.of(page, size, Sort.by("name"));
        return employeeRepository.findEmployeesByDepartmentName(departmentName, pageRequest);
    }

    public Page<Employee> getEmployeesByNameStartingWith(String name, int page, int size) {
        PageRequest pageRequest = PageRequest.of(page, size, Sort.by("name"));
        return employeeRepository.findEmployeesByNameStartingWith(name, pageRequest);
    }
}
