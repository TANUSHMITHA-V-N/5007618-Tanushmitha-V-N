package com.example.EmployeeManagementSystem.service;


import com.example.EmployeeManagementSystem.repository.BatchEmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class BatchEmployeeService {
    @Autowired
    private BatchEmployeeRepository batchEmployeeRepository;

    @Transactional
    public void updateEmployeeNames(List<Long> ids, String name) {
        batchEmployeeRepository.updateEmployeeNames(ids, name);
    }
}
