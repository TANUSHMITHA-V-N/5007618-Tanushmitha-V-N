package com.example.EmployeeManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.employeemanagementsystem.entity.department.Department;
import com.example.EmployeeManagementSystem.entity.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    // 1. Defining Query Methods using keywords
    List<Department> findByNameContaining(String name);

    // 2. Implementing custom query methods using @Query
    @Query("SELECT d FROM Department d WHERE d.name LIKE ?1%")
    List<Department> findDepartmentsByNameContaining(String name);
}